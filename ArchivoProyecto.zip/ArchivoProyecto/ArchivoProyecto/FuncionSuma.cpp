int sumar(int NumeroUno, int NumeroDos)
{
	int suma_de_numeros;
	suma_de_numeros = NumeroUno + NumeroDos;
	return(suma_de_numeros);
}