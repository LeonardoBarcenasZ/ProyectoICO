int  dividir(int NumeroUno, int NumeroDos)
{
	int division_de_numeros;
	division_de_numeros = NumeroUno / NumeroDos;
	return (division_de_numeros);
}