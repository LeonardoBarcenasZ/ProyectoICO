int restar(int NumeroUno, int NumeroDos)
{
	int resta_de_numeros;
	resta_de_numeros = NumeroUno - NumeroDos;
	return(resta_de_numeros);
}