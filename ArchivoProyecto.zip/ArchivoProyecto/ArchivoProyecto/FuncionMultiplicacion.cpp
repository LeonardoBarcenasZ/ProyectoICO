int  multiplicar(int NumeroUno, int NumeroDos)
{
	int multi_de_numeros;
	multi_de_numeros = NumeroUno * NumeroDos;
	return (multi_de_numeros);
}